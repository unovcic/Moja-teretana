MOJA TERETANA – iPhone PWA

SADRŽAJ
- index.html: aplikacija
- manifest.json: podešavanja instalacije
- sw.js: keširanje za rad bez mreže nakon prvog učitavanja

VAŽNO
Aplikacija čuva treninge automatski u IndexedDB memoriji pregledača na iPhone-u.
Podaci su lokalni na tom uređaju i nisu sinhronizovani sa drugim uređajima.
Izvezite rezervnu kopiju povremeno iz kartice „Podaci”.

KAKO DA JE DODAŠ NA POČETNI EKRAN
1. Objavi sva tri fajla na HTTPS hostingu (npr. GitHub Pages ili drugi statički hosting).
2. Na iPhone-u otvori objavljenu HTTPS adresu u Safariju.
3. Pritisni Share / Deljenje.
4. Izaberi Add to Home Screen / Dodaj na početni ekran.
5. Potvrdi Add / Dodaj.

Ne otvaraj index.html kao običan lokalni fajl iz aplikacije Files ako želiš instalaciju i pouzdan rad van mreže. Za PWA je potreban HTTPS hosting.

Napomena: ovo je web aplikacija za ličnu upotrebu, nije objavljena u App Store-u.
